// app/layout.tsx
import { Playfair_Display, Lato } from "next/font/google";
import "../globals.css";
import TransitionWrapper from "./TransitionWrapper";
import { ClerkProvider } from "@clerk/nextjs";
import { LanguageProvider } from "../contexts/LanguageContext";
import { ThemeProvider } from "next-themes";
import dynamic from "next/dynamic";
import { AuthProvider } from "@/contexts/AuthContext";
import SmoothScroll from "../components/SmoothScroll";
import Navbar from "../components/Navbar";
import CapacitorInitWrapper from "../capacitor/CapacitorInitWrapper";
import { NotificationProvider } from "@/contexts/NotificationContext";

import OfflineBanner from "../components/OfflineBanner";

const SplashScreen = dynamic(() => import("../components/SplashScreen"));

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const lato = Lato({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-lato",
  display: "swap",
});

import type { Metadata } from "next";

export const metadata: Metadata = {
  metadataBase: new URL("https://gevabal.mn"),
  title: "Gevabal - Spiritual Guidance",
  description: "Book spiritual consultations with experienced monks",
  icons: {
    icon: "/logo.png",
    shortcut: "/logo.png",
    apple: "/logo.png",
  },
  alternates: {
    canonical: "./",
    languages: {
      en: "/en",
      mn: "/mn",
    },
  },
};

export default async function RootLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const validLocale = (["mn", "en"].includes(locale) ? locale : "mn") as
    | "mn"
    | "en";

  const serverUser = null;

  // We rely on the client-side AuthContext calling /api/auth/me to properly hydrate user
  // and load complex MongoDB/JWT state without blocking Server Side Rendering (SSR)

  return (
    <ClerkProvider>
      <LanguageProvider initialLocale={validLocale}>
        <AuthProvider initialUser={serverUser}>
          <html lang={validLocale} suppressHydrationWarning>
            <head>
              {/* Mobile viewport for edge-to-edge design */}
              <meta
                name="viewport"
                content="width=device-width, initial-scale=1.0, viewport-fit=cover, maximum-scale=1.0, user-scalable=no"
              />
              {/* iOS PWA meta tags */}
              <meta name="apple-mobile-web-app-capable" content="yes" />
              <meta
                name="apple-mobile-web-app-status-bar-style"
                content="black-translucent"
              />
              <meta name="mobile-web-app-capable" content="yes" />
              {/* Theme color for Android status bar to match cream background */}
              <meta name="theme-color" content="#FDFBF7" />
              {/* Preconnects */}
              <link rel="preconnect" href="https://res.cloudinary.com" />
              <link rel="dns-prefetch" href="https://res.cloudinary.com" />
              <link rel="preconnect" href="https://clerk-telemetry.com" />
              <link rel="preconnect" href="https://img.clerk.com" />
            </head>
            <body
              className={`${playfair.variable} ${lato.variable} font-sans overflow-x-hidden`}
            >
              <ThemeProvider
                attribute="class"
                forcedTheme="light"
                defaultTheme="light"
                enableSystem={false}
              >
                <OfflineBanner />
                <CapacitorInitWrapper />
                <SmoothScroll />
                <NotificationProvider>
                  <Navbar />
                  <SplashScreen />
                  <main
                    className="w-full relative overflow-x-hidden"
                    style={{
                      paddingBottom:
                        "calc(env(safe-area-inset-bottom, 0px) + 76px)",
                    }}
                  >
                    <TransitionWrapper>{children}</TransitionWrapper>
                  </main>
                </NotificationProvider>
              </ThemeProvider>
            </body>
          </html>
        </AuthProvider>
      </LanguageProvider>
    </ClerkProvider>
  );
}
// CAP_INJECT_PARAMS
export function generateStaticParams() {
  return [{ locale: "mn" }, { locale: "en" }];
}
