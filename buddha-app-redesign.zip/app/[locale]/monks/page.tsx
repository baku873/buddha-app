"use client";

import React, { useState, useEffect, useCallback } from "react";
import { usePlatform } from "@/app/capacitor/hooks/usePlatform";
import MonkShowcaseClient from "../../components/MonkShowcaseClient";
import MobileScrollView from "../../components/mobile/MobileScrollView";
import { SkeletonMonkList } from "../../components/SkeletonCard";
import { Monk } from "@/database/types";

export default function MonksPage(): React.JSX.Element {
  const { isNative } = usePlatform();
  const [monks, setMonks] = useState<Monk[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchMonks = useCallback(async (): Promise<void> => {
    try {
      const res: Response = await fetch("/api/monks");
      if (res.ok) {
        const data: Monk[] = await res.json();
        const serialized: Monk[] = data.map(
          (m: Monk): Monk => ({
            ...m,
            _id: m._id?.toString() ?? "",
          }),
        );
        serialized.sort((a: Monk, b: Monk): number => {
          if (a.isSpecial && !b.isSpecial) return -1;
          if (!a.isSpecial && b.isSpecial) return 1;
          return 0;
        });
        setMonks(serialized);
      }
    } catch (err: unknown) {
      console.error("Failed to fetch monks:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMonks();
  }, [fetchMonks]);

  const refetch = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    await fetchMonks();
  }, [fetchMonks]);

  if (isLoading) {
    return (
      <MobileScrollView pullToRefresh={isNative} onRefresh={refetch}>
        <div className="min-h-svh bg-cream pb-24 px-5 pt-6">
          <SkeletonMonkList count={4} />
        </div>
      </MobileScrollView>
    );
  }

  return <MonkShowcaseClient initialMonks={monks} />;
}
