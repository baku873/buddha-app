import { cache, Suspense } from "react";
import dynamic from "next/dynamic";
import Hero from "../components/Hero";
import HomeSections from "../components/HomeSections";
import { connectToDatabase } from "@/database/db";
import { Monk } from "@/database/types";

const PhilosophySection = dynamic(() => import("../components/Philosophy"));
const NirvanaComments = dynamic(() => import("../components/NirvanaComments"));

const getMonks = cache(async () => {
  try {
    const { db } = await connectToDatabase();
    const monks = (await db
      .collection("users")
      .find({ role: "monk", isAvailable: { $ne: false } })
      .toArray()) as unknown as Monk[];
    return monks
      .map((m) => ({ ...m, _id: m._id?.toString() ?? "" }))
      .sort((a, b) => {
        if (a.isSpecial && !b.isSpecial) return -1;
        if (!a.isSpecial && b.isSpecial) return 1;
        if (a.monkNumber !== undefined && b.monkNumber !== undefined)
          return a.monkNumber - b.monkNumber;
        return 0;
      });
  } catch {
    return [];
  }
});

const getBlogs = cache(async () => {
  try {
    const { db } = await connectToDatabase();
    const blogs = await db
      .collection("blogs")
      .find({})
      .sort({ date: -1 })
      .limit(5)
      .project({
        _id: 1,
        id: 1,
        title: 1,
        content: 1,
        date: 1,
        cover: 1,
        category: 1,
        authorName: 1,
      })
      .toArray();
    return blogs.map((blog) => ({
      _id: blog._id.toString(),
      id: blog.id || blog._id.toString(),
      title: blog.title || { mn: "", en: "" },
      date: blog.date
        ? new Date(blog.date).toISOString()
        : new Date().toISOString(),
      cover: blog.cover || "",
      category: blog.category || "Wisdom",
      authorName: blog.authorName || "Багш",
    }));
  } catch {
    return [];
  }
});

export default async function Home({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  // Parallel Fetch (O(1) sequential wait)
  const [allMonks, blogs] = await Promise.all([getMonks(), getBlogs()]);

  const featuredMonks = allMonks.slice(0, 3);

  return (
    <>
      <Hero blogs={blogs} locale={locale} />
      <HomeSections
        locale={locale}
        blogs={blogs}
        monks={allMonks}
        featuredMonks={featuredMonks}
      />
    </>
  );
}
