// ─── Server Component: fetches data at request/build time ────────────────────
// HomeClientWrapper handles pull-to-refresh via router.refresh()

import { connectToDatabase } from "@/database/db";
import HomeClientWrapper from "./HomeClientWrapper";

interface HomeBlog {
  _id: string;
  id: string;
  title: { mn: string; en: string };
  date: string;
  cover: string;
  category: string;
  authorName: string;
}

interface MonkRow {
  isAvailable?: boolean;
  isSpecial?: boolean;
  monkNumber?: number;
  _id?: { toString(): string } | string;
  [key: string]: unknown;
}

interface BlogRow {
  _id?: { toString(): string } | string;
  id?: string;
  title?: { mn: string; en: string };
  date?: string;
  cover?: string;
  category?: string;
  authorName?: string;
  [key: string]: unknown;
}

export default async function Home({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<React.JSX.Element> {
  const { locale } = await params;
  const validLocale: "mn" | "en" = ["mn", "en"].includes(locale)
    ? (locale as "mn" | "en")
    : "mn";

  let monks: unknown[] = [];
  let blogs: HomeBlog[] = [];

  try {
    const { db } = await connectToDatabase();

    const [rawMonks, rawBlogs] = await Promise.all([
      db
        .collection("users")
        .find(
          {
            role: "monk",
            $or: [
              { "name.en": { $exists: true, $ne: "" } },
              { "name.mn": { $exists: true, $ne: "" } },
            ],
          },
          {
            projection: {
              clerkId: 1,
              name: 1,
              title: 1,
              image: 1,
              imageUrl: 1,
              isAvailable: 1,
              isSpecial: 1,
              specialties: 1,
              role: 1,
              phone: 1,
              email: 1,
              avatar: 1,
              firstName: 1,
              lastName: 1,
              karma: 1,
              totalMerits: 1,
              earnings: 1,
              showOnHomepage: 1,
              monkNumber: 1,
              video: 1,
              services: 1,
            },
          },
        )
        .toArray(),
      db.collection("blogs").find({}).sort({ date: -1 }).limit(5).toArray(),
    ]);

    monks = (rawMonks as MonkRow[])
      .filter((m: MonkRow): boolean => m.isAvailable !== false)
      .map((m: MonkRow): MonkRow => ({ ...m, _id: m._id?.toString() ?? "" }))
      .sort((a: MonkRow, b: MonkRow): number => {
        if (a.isSpecial && !b.isSpecial) return -1;
        if (!a.isSpecial && b.isSpecial) return 1;
        if (a.monkNumber !== undefined && b.monkNumber !== undefined)
          return a.monkNumber - b.monkNumber;
        return 0;
      });

    blogs = (rawBlogs as BlogRow[]).map(
      (blog: BlogRow): HomeBlog => ({
        _id: blog._id?.toString() || "",
        id: blog.id || blog._id?.toString() || "",
        title: blog.title || { mn: "", en: "" },
        date: blog.date
          ? new Date(blog.date).toISOString()
          : new Date().toISOString(),
        cover: blog.cover || "",
        category: blog.category || "Wisdom",
        authorName: blog.authorName || "Багш",
      }),
    );
  } catch (error: unknown) {
    console.error("Home page: failed to fetch data:", error);
  }

  return <HomeClientWrapper monks={monks} blogs={blogs} locale={validLocale} />;
}

export function generateStaticParams(): { locale: string }[] {
  return [{ locale: "mn" }, { locale: "en" }];
}
