"use client";

import React, { useState, useEffect, useCallback } from "react";
import { usePlatform } from "@/app/capacitor/hooks/usePlatform";
import BlogListClient from "../../components/BlogListClient";
import MobileScrollView from "../../components/mobile/MobileScrollView";
import { SkeletonBlogList } from "../../components/SkeletonCard";

interface ApiBlogResponse {
  id?: string;
  _id?: { toString(): string };
  title?: Record<string, string>;
  content?: Record<string, string>;
  date?: string;
  cover?: string;
  category?: string;
  authorName?: string;
  authorId?: string | { toString(): string };
}

interface BlogPost {
  id: string;
  title: Record<string, string>;
  content: Record<string, string>;
  date: string;
  cover: string;
  category: string;
  authorName: string;
  authorId: string;
}

export default function BlogPage(): React.JSX.Element {
  const { isNative } = usePlatform();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchBlogs = useCallback(async (): Promise<void> => {
    try {
      const res: Response = await fetch("/api/blogs");
      if (res.ok) {
        const data: ApiBlogResponse[] = await res.json();
        const serialized: BlogPost[] = data.map(
          (blog: ApiBlogResponse): BlogPost => ({
            id: blog.id || blog._id?.toString() || "",
            title: blog.title || { mn: "", en: "" },
            content: blog.content || { mn: "", en: "" },
            date: blog.date
              ? new Date(blog.date).toISOString()
              : new Date().toISOString(),
            cover: blog.cover || "",
            category: blog.category || "Wisdom",
            authorName: blog.authorName || "Багш",
            authorId: blog.authorId ? blog.authorId.toString() : "",
          }),
        );
        setPosts(serialized);
      }
    } catch (err: unknown) {
      console.error("Failed to fetch blogs:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBlogs();
  }, [fetchBlogs]);

  const refetch = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    await fetchBlogs();
  }, [fetchBlogs]);

  if (isLoading) {
    return (
      <MobileScrollView pullToRefresh={isNative} onRefresh={refetch}>
        <div className="min-h-svh bg-[#FAFAFA] px-6 pt-6 pb-24">
          <SkeletonBlogList count={3} />
        </div>
      </MobileScrollView>
    );
  }

  return <BlogListClient initialPosts={posts} />;
}
