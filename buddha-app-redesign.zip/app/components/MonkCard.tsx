"use client";

import React from "react";
import Image from "next/image";
import { Monk } from "@/database/types";
import { useLanguage } from "../contexts/LanguageContext";
import { Heart, Star, ArrowRight } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface MonkCardProps {
    monk: Monk;
    index?: number;
    onClick?: () => void;
}

export default function MonkCard({ monk, index = 0, onClick }: MonkCardProps) {
    const { t, language: lang } = useLanguage();
    const { user } = useAuth();
    const validLang = (['mn', 'en'].includes(lang) ? lang : 'mn') as 'mn' | 'en';

    const name = monk.name?.[validLang] || monk.name?.mn || monk.name?.en || "Unknown";
    const titleText = monk.title?.[validLang] || monk.title?.mn || monk.title?.en || "Үзмэрч";
    const years = monk.yearsOfExperience || 10;
    const price = (monk.services && monk.services[0]?.price) 
        ? monk.services[0].price.toLocaleString() 
        : (monk.isSpecial ? "100,000" : "50,000");
    const isOnline = monk.isAvailable !== false;
    const rating = (monk as any).rating || "4.8";
    const reviews = (monk as any).reviews || 65;

    const specialty = Array.isArray(monk.specialties) && monk.specialties.length > 0
        ? monk.specialties[0]
        : (validLang === 'en' ? "Spiritual Guide" : "Засалч");

    return (
        <motion.div
            onClick={onClick}
            className="bg-white border border-border p-3 mb-4 flex gap-4 items-center cursor-pointer active:scale-[0.97] transition-transform rounded-[16px] shadow-[0_2px_12px_rgba(0,0,0,0.08)] h-[96px]"
        >
            {/* Avatar & Status */}
            <div className="relative w-[72px] h-[72px] flex-shrink-0">
                <div className={`absolute inset-0 rounded-xl ${!isOnline && "bg-stone/50"}`} />
                <div className="relative w-full h-full rounded-xl overflow-hidden shadow-sm z-10">
                    <Image
                        src={monk.image || "/default-monk.jpg"}
                        alt={name}
                        fill
                        priority={index < 3}
                        loading={index < 3 ? undefined : "lazy"}
                        className="object-cover"
                        unoptimized={true}
                        sizes="128px"
                        onError={(e) => { e.currentTarget.src = '/logo.webp'; }}
                    />
                </div>
                {isOnline && (
                     <div className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-[#10B981] rounded-full border-2 border-white z-20 animate-pulse shadow-sm" />
                )}
            </div>

            {/* Info Container */}
            <div className="flex-1 min-w-0 pr-2 overflow-hidden">
                <div className="flex flex-col gap-0.5">
                    <h3 className="text-base font-black text-ink leading-tight truncate">{name}</h3>
                    <p className="text-[10px] font-black text-gold uppercase tracking-widest opacity-80 line-clamp-1">{titleText}</p>
                </div>

                <p className="text-[11px] text-earth/60 mt-0.5 truncate">{specialty} · {years} жил</p>

                <div className="flex items-center gap-1.5 mt-1">
                    <div className="flex items-center gap-1">
                        <Star size={10} className="text-gold fill-gold" />
                        <span className="text-[11px] font-black text-ink">{rating}</span>
                        <span className="text-[10px] text-earth/40">({reviews})</span>
                    </div>
                </div>
            </div>

            {/* Right: Booking Focus */}
            <div className="flex flex-col items-end shrink-0 gap-1">
                <p className="text-sm font-bold text-gold">₮{price}</p>
                <div className="w-[40px] h-[40px] rounded-full bg-gold flex items-center justify-center text-white shadow-sm">
                    <ArrowRight size={18} />
                </div>
            </div>
        </motion.div>
    );
}
