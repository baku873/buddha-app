"use client"

import { useEffect } from 'react'
import { Capacitor } from '@capacitor/core'

export default function SmoothScroll() {
  useEffect(() => {
    // Native Capacitor handles scroll natively — Lenis fights it
    if (Capacitor.isNativePlatform()) return;

    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;
    if (prefersReducedMotion) return;

    let lenis: any;

    const init = async () => {
      const { default: Lenis } = await import('lenis');
      lenis = new Lenis({
        duration: 1.1,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
        touchMultiplier: 0,   // zero — let native touch scroll handle mobile
        infinite: false,
      });

      function raf(time: number) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
    };

    init();

    return () => {
      lenis?.destroy();
    };
  }, []);

  return null;
}
