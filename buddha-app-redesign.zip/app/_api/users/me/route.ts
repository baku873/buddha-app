import { NextRequest, NextResponse } from "next/server";
import { getCollection } from "@/app/lib/mongodb";
import { ObjectId } from "mongodb";
import { clerkClient } from "@clerk/nextjs/server";
import { auth } from "@/app/lib/auth";

/**
 * Endpoint for self-serve account deletion (App Store Guideline 5.1.1 compliance)
 */
export async function DELETE(req: NextRequest) {
    try {
        const authData = await auth();
        
        if (!authData || !authData.userId) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const userId = authData.userId;

        let query: any = {
            $or: [
                { clerkId: userId },
                { _id: userId as any }
            ]
        };
        if (ObjectId.isValid(userId)) {
            query.$or.push({ _id: new ObjectId(userId) });
        }

        // Ensure we purge from both potential collections securely
        const usersCollection = await getCollection("users");
        await usersCollection.deleteOne(query);

        const monksCollection = await getCollection("monks");
        await monksCollection.deleteOne(query);

        // Revoke the Clerk account
        const client = await clerkClient();
        try {
            await client.users.deleteUser(userId);
        } catch (e: any) {
            console.error("Clerk user deletion error. May already be deleted or is custom auth:", e);
        }

        return NextResponse.json({ success: true, message: "Account fully deleted" });

    } catch (e: any) {
        console.error("[DELETE /api/users/me] Exception:", e);
        return NextResponse.json({ error: e.message || "Failed to delete account" }, { status: 500 });
    }
}
