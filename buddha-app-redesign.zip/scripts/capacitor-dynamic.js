const fs = require('fs');
const path = require('path');

const action = process.argv[2];
const apiDir = path.join(__dirname, '..', 'app/api');
const hiddenApiDir = path.join(__dirname, '..', 'app/_api');

const robotsPath = path.join(__dirname, '..', 'app/robots.ts');
const hiddenRobotsPath = path.join(__dirname, '..', 'app/_robots.ts');
const sitemapPath = path.join(__dirname, '..', 'app/sitemap.ts');
const hiddenSitemapPath = path.join(__dirname, '..', 'app/_sitemap.ts');

function walk(dir, callback) {
    if (!fs.existsSync(dir)) return;
    fs.readdirSync(dir).forEach(f => {
        let dirPath = path.join(dir, f);
        let isDirectory = fs.statSync(dirPath).isDirectory();
        isDirectory ? walk(dirPath, callback) : callback(path.join(dir, f));
    });
}

const targetDirs = ['app/[locale]', 'app/api'].map(d => path.join(__dirname, '..', d));

if (action === 'remove') {
    if (process.env.CAPACITOR_BUILD !== 'true') return;
    
    if (fs.existsSync(apiDir)) {
        fs.renameSync(apiDir, hiddenApiDir);
        console.log("[Capacitor] Temporarily hid app/api to bypass API static export limits.");
    }
    if (fs.existsSync(robotsPath)) {
        fs.renameSync(robotsPath, hiddenRobotsPath);
        console.log("[Capacitor] Temporarily hid app/robots.ts");
    }
    if (fs.existsSync(sitemapPath)) {
        fs.renameSync(sitemapPath, hiddenSitemapPath);
        console.log("[Capacitor] Temporarily hid app/sitemap.ts");
    }
    
    let modified = 0;
    targetDirs.forEach(dir => {
        walk(dir, (filePath) => {
            if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
                let content = fs.readFileSync(filePath, 'utf-8');
                let changed = false;
                const regex = /^\s*(export\s+const\s+dynamic\s*=\s*['"][\w-]+['"];?)/gm;
                if (regex.test(content)) {
                    content = content.replace(regex, '// CAP_DISABLE: $1');
                    changed = true;
                }
                
                if ((filePath.includes('page.tsx') || filePath.includes('layout.tsx')) && filePath.includes('[')) {
                    if (!content.includes('generateStaticParams')) {
                        let dyns = [];
                        filePath.split(path.sep).forEach(s => {
                            let match = s.match(/\[(.*?)\]/);
                            if (match) dyns.push(match[1]);
                        });
                        
                        if (dyns.length === 1 && dyns[0] === 'locale') {
                            content += '\n// CAP_INJECT_PARAMS\nexport function generateStaticParams() { return [{ locale: "mn" }, { locale: "en" }]; }\n';
                        } else {
                            content += '\n// CAP_INJECT_PARAMS\nexport function generateStaticParams() { return []; }\n';
                        }
                        changed = true;
                    }
                }
                
                if (changed) {
                    fs.writeFileSync(filePath, content, 'utf-8');
                    modified++;
                }
            }
        });
    });
    if (modified > 0) console.log(`[Capacitor] Temporarily disabled dynamic exports and injected params in ${modified} files.`);
} else if (action === 'restore') {
    if (fs.existsSync(hiddenApiDir)) {
        fs.renameSync(hiddenApiDir, apiDir);
        console.log("[Capacitor] Restored app/api.");
    }
    if (fs.existsSync(hiddenRobotsPath)) {
        fs.renameSync(hiddenRobotsPath, robotsPath);
        console.log("[Capacitor] Restored app/robots.ts");
    }
    if (fs.existsSync(hiddenSitemapPath)) {
        fs.renameSync(hiddenSitemapPath, sitemapPath);
        console.log("[Capacitor] Restored app/sitemap.ts");
    }

    let restored = 0;
    targetDirs.forEach(dir => {
        walk(dir, (filePath) => {
            if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
                let content = fs.readFileSync(filePath, 'utf-8');
                let changed = false;
                const regex = /^\/\/\s*CAP_DISABLE:\s*(export\s+const\s+dynamic\s*=\s*['"][\w-]+['"];?)/gm;
                if (regex.test(content)) {
                    content = content.replace(regex, '$1');
                    changed = true;
                }
                
                const injRegex = /\/\/\s*CAP_INJECT_PARAMS[\s\S]*?export function generateStaticParams.*?\}[ \t]*\n?/g;
                if (injRegex.test(content)) {
                    content = content.replace(injRegex, '');
                    changed = true;
                }
                
                if (changed) {
                    fs.writeFileSync(filePath, content, 'utf-8');
                    restored++;
                }
            }
        });
    });
    if (restored > 0) console.log(`[Capacitor] Restored dynamic exports in ${restored} files.`);
} else {
    console.error("Please specify 'remove' or 'restore'");
    process.exitCode = 1;
}
